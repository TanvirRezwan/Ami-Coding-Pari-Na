from django.db import models
from .gangster import Gangster  

class InputValues(models.Model):
    gangster = models.ForeignKey(Gangster, on_delete=models.CASCADE)
    values = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-timestamp']