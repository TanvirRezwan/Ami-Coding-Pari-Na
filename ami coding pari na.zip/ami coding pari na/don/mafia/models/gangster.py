from django.db import models

class Gangster(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    phone = models.CharField(max_length=15)
    email = models.EmailField()
    password = models.CharField(max_length=500)

    def register(self):
        self.save()

    @staticmethod
    def get_gangster_by_email(email):
        try:
            return Gangster.objects.get(email=email)
        except Gangster.DoesNotExist:
            return None

    def isExists(self):
        return Gangster.objects.filter(email=self.email).exists()

from django.db import models
class InputValues(models.Model):
    gangster = models.ForeignKey(Gangster, on_delete=models.CASCADE)
    values = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-timestamp']
