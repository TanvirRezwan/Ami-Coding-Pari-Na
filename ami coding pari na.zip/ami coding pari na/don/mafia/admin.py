from django.contrib import admin
from .models.gangster import Gangster, InputValues

admin.site.register(Gangster)
admin.site.register(InputValues)
